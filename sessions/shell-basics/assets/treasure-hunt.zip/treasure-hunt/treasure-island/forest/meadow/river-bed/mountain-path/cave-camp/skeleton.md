```
    \ /
    oVo
\___XXX___/
 __XXXXX__
/__XXXXX__\
/   XXX   \
     V
```

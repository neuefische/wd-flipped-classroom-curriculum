```
+------------------+
|                  |
|    use ls -la    |
|       near       |
|   the altar in   |
|    the sacred    |
|       halls.     |
|                  |
+------------------+
```

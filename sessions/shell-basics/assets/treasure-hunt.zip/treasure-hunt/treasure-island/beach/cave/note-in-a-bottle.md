+-----------------+
|									+--+
| Hey Barry,  			 |
|										 |
| come and visit me  |
| in my cave, you    |
| have a beautiful   |
|	view from up here. |
|	Just follow the    |
|	river.             |
|										 |
|	Garry              |
|                    |
|                    |
+--------------------+

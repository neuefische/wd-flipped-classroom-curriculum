# Exercise: Treasure Hunt

Welcome to the treasure hunt!

Find the `treasure` on the treasure-island (the folder) only by browsing the folders inside your
terminal.

- use `cd` to change directories
- use `cd ..` to move out of the current folder
- use `ls` to look what is in the current folder
- use `cat` to see what is inside a markdown file
- use `pwd` to see your current directory path
